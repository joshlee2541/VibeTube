package com.leetech.vibetube;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AppBridge(this), "VibeTubeAndroid");
        webView.setWebViewClient(new WebViewClient());
        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> startDownload(url, null, mimetype));
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void startDownload(String rawUrl, String suggestedName, String mimeType) {
        try {
            Uri uri = Uri.parse(rawUrl);
            String scheme = uri.getScheme();
            if (scheme == null || !(scheme.equals("https") || scheme.equals("http"))) {
                Toast.makeText(this, "Please use a direct HTTP or HTTPS download link.", Toast.LENGTH_LONG).show();
                return;
            }
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle(suggestedName == null || suggestedName.trim().isEmpty() ? "VibeTube download" : suggestedName);
            request.setDescription("Downloading to your Downloads folder");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "VibeTube_" + System.currentTimeMillis() + fileExtension(uri.getLastPathSegment(), mimeType));
            String cookie = android.webkit.CookieManager.getInstance().getCookie(rawUrl);
            if (cookie != null) request.addRequestHeader("Cookie", cookie);
            String ua = webView.getSettings().getUserAgentString();
            if (ua != null) request.addRequestHeader("User-Agent", ua);
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);
            Toast.makeText(this, "Download started. Check notifications or Downloads.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not start this download. Check the link and try again.", Toast.LENGTH_LONG).show();
        }
    }

    private String fileExtension(String path, String mime) {
        if (path != null && path.matches(".*\\.[A-Za-z0-9]{2,5}$")) return path.substring(path.lastIndexOf('.'));
        if (mime != null && mime.contains("mp4")) return ".mp4";
        if (mime != null && mime.contains("audio")) return ".mp3";
        return ".bin";
    }

    private class AppBridge {
        private final Context context;
        AppBridge(Context context) { this.context = context; }

        @JavascriptInterface public void openWeb(String rawUrl) {
            runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(rawUrl);
                    String scheme = uri.getScheme();
                    if (scheme == null || !(scheme.equals("https") || scheme.equals("http"))) throw new IllegalArgumentException();
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(context, "That link could not be opened.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface public void downloadDirect(String rawUrl, String filename) {
            runOnUiThread(() -> startDownload(rawUrl, filename, null));
        }

        @JavascriptInterface public void showDownloads() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); }
                catch (Exception e) { Toast.makeText(context, "Open your phone's Downloads app to see files.", Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
