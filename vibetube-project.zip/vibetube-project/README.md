# VibeTube Android app

An original Android video discovery and direct-file download starter app. It was inspired by the general idea of a video hub; it does not reuse SnapTube's proprietary source code, branding, or assets.

## Features
- Original VibeTube home screen
- Shortcuts to YouTube, TikTok, Facebook Watch, and Vimeo in the external browser
- Search videos on YouTube
- Download direct HTTP/HTTPS file URLs to the Android Downloads folder using Android DownloadManager
- Open the Android Downloads screen
- GitHub Actions workflow to build a debug APK

## Important limitations
- This starter version opens video platforms in the external browser; it is not an embedded copy of their apps.
- It only downloads direct file URLs when the source permits it. It does not extract media streams from platforms, bypass DRM, or evade subscription/download restrictions.
- Internet access is required. The project has not been compiled or tested in this environment.

## Build an APK using GitHub (free)
1. Create a GitHub repository named `vibetube`.
2. Extract this ZIP on your phone or computer and upload the **contents** of this folder to the repository root (so `app/`, `build.gradle`, `settings.gradle`, and `.github/` are at the root).
3. Open the repository's **Actions** tab. If prompted, enable workflows.
4. Select **Build VibeTube APK** and tap **Run workflow**. Alternatively, push the files to the `main` branch to trigger a build.
5. When the run succeeds, open it and download the `VibeTube-debug-APK` artifact.
6. Extract the artifact ZIP. Install `app-debug.apk` on your Android phone. Android may ask you to allow installs from that browser or file manager.

## Package
`com.leetech.vibetube`
